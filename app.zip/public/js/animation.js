var animation = bodymovin. loadAnimation
({
    container : document.getElementById('anim'),
    rederer:'svg',
    autoplay: true,
    path:'data3.json'   
})